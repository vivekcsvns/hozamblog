<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'tbozam_blog' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'o){*qNLGpt2fG`p%F9,<nGGr|h~n~P-#4WMS8Rf6k5u@q,-sD=7fs b_:-pU!tk}');
define('SECURE_AUTH_KEY',  't_)w_TB)v^vnVGE08*/ SC+O}6>Mdwv4w146-)=gO5-+bXb:i!mEz2:9$;::nm4y');
define('LOGGED_IN_KEY',    '!?LyI3XVh>gCMB}mbBx3D`u&/C-60ZJ$ *xUQPx#A~L<?g4{W>&F@O,9hXm.eB>N');
define('NONCE_KEY',        '.emw+x7],CJUmGJVk02/I?9^C!]MICuo(#bFS={:vP3+|r=7H,?sP2w59QW}FM@f');
define('AUTH_SALT',        'V6Cse.c[$O>Su_Go3gm^{*5C9@un[( @uCqq6@2{k&Io<x3reIHHbTb<k`K^Z*{w');
define('SECURE_AUTH_SALT', '[{&g-z82=p ~xvdy$|n e4/nFlKhF.,gr~-9H(9|`:|T`Ye6GYXzN?5|50VDLsvA');
define('LOGGED_IN_SALT',   'tM%c``U;joQ=E(d*UABIy&{tJ(PDDre+0#n2/askA},I.w03!4+{nh=A3|V`BjeJ');
define('NONCE_SALT',       'z%lEiWBY[4!X6G,Lr.Z+OhmzwhX}?OB.#HgL^_o[|M])M|4wB,D-[}#}W)*&q.+.');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_zam_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
